
//网站名称
var webname = 'QAdmin';

//菜单列表路径 可以是本地json 也可以是api接口
var menuUrl = 'data/menu.json';

